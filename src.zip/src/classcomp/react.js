import React from 'react';
import ReactDOM from 'react-dom';
import Heading from './Heading'

ReactDOM.render(

  <Heading />
  document.getElementById('root')
  );