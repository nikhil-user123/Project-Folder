import React from 'react';
import ReactDOM from 'react-dom';
function Heading(){
	return <h1> Heading </h1>;
}

export default Heading;