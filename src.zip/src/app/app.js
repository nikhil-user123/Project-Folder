import React from "react";
  
class Sample   extends React.Component {
  render() {
    return <h1>Hello js  </h1>;
  }
}
  
class App extends React.Component {
  render() {
    return <Sample />;
  }
}
  
export default App;