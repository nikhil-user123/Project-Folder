import React from 'react';


const Html=()=>{
		return(

			<>
			 	
		 	 <div className="hero-section">
				<p>So!! Here is our Today's Topic</p>
				<h1>Anchor Tag</h1>
				
					<p className="center">The &lt;a&gt; tag defines a hyperlink, which is used to link from one page to another.
					
							The most important attribute of the element is the href attribute, which indicates the link's destination.

							By default, links will appear as follows in all browsers:

							An unvisited link is underlined and blue
							A visited link is underlined and purple
							An active link is underlined and red
					</p>
					
                
			 </div>	

			</>
			);
}



export default Html; 