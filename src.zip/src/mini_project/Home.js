import React from 'react';


const Html=()=>{
		return(

			<>
			 	
			 	<p className="center">Home Page</p>
		 	 
			</>
			);
}



export default Html; 