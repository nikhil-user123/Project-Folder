import react from 'react';
import reactDom from 'react-dom';



const Intro=()=>{
    return(

        <>
             
             <h1> Nikhil Netflix </h1>
             <p > Here the list of my five Netflix series</p>
             <br></br>
             <ol>
                <li>Coffee</li>
                <li>Tea</li>
                <li>Milk</li>
            </ol> 

          
        </>
        );
}



export default Intro; 